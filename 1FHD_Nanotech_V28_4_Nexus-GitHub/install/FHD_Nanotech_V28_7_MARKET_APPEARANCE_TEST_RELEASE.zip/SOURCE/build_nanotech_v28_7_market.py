from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import sys, hashlib
sys.path.insert(0, '/mnt/data')
from dat_codec import unpack,pack,walk,dump

BASE=Path('/mnt/data/FHD_Nanotech_V28_4_VANILLA_P5_TEST_RELEASE.zip')
OUT=Path('/mnt/data/FHD_Nanotech_V28_7_MARKET_APPEARANCE_TEST_RELEASE.zip')
PREFIX='Mods/FHD_MODS/FHD_Nanotech/'

def group(t,name):
    xs=[e[3] for e in t[1] if e[1]==2 and e[2]==name]
    assert len(xs)==1,(name,len(xs))
    return xs[0]
def parm(t,name):
    xs=[e for e in t[1] if e[1]==1 and e[2]==name]
    assert len(xs)==1,(name,len(xs))
    return xs[0]
def mkparm(name,value,kind=1):
    return [b'\0\0\0\0\1\0\0\0',kind,name,value]
def mkgroup(name,items):
    return mkparm(name,[1,items],2)

market_code = [
    'if(!h || ItemType(h)!=t_Hull) exit;',
    "if(CT('FHDNT.Distribution27')!='VANILLA') exit;",
    "if(ItemExtraSpecialsCountByType(h,FindBonusByNameInCfg('FHDNT_Mark'))==1) exit;",
    'int nm_hull_type=HullType(h);',
    'if(nm_hull_type!=0 && nm_hull_type!=3 && nm_hull_type!=4 && nm_hull_type!=5) exit;',
    'int nm_old_series=HullSeries(h);',
    'if(nm_old_series<0 || nm_old_series>=SeriesCount()) exit;',
    'str nm_old_name=SeriesNumInCfg(nm_old_series);',
    "if(nm_old_name!='120' && nm_old_name!='121' && nm_old_name!='122' && nm_old_name!='123' && nm_old_name!='124') exit;",
    # Id is stable per game save, so repeated shop opens do not re-roll or
    # increase chance. It checks only existing stock already traversed by StockAt.
    'int nm_roll=Id(h)%100;',
    'if(nm_roll<0) nm_roll=-nm_roll;',
    "if(nm_roll>=CT('FHDNT.ShopExtraChance28')) exit;",
    'int nm_new_series=-1;',
    'int nm_i=0;',
    'for(nm_i=0;nm_i<SeriesCount();nm_i=nm_i+1)',
    "if(SeriesNumInCfg(nm_i)=='FHDNT_Nanotechnician') {nm_new_series=nm_i;break;}",
    'if(nm_new_series<0) exit;',
    'HullSeries(h,nm_new_series);',
    "ExecuteCodeFromString(GenerateCodeStringFromBlock('FHDNT.Code.PrepareHull27'),'h',h);",
    # If skins could not be initialized, restore original standard series.
    "if(ItemExtraSpecialsCountByType(h,FindBonusByNameInCfg('FHDNT_Mark'))!=1) HullSeries(h,nm_old_series);",
]
assert len(market_code)==20

readme='''FHD_Nanotech V28.7 — ИСПРАВЛЕННОЕ ПОЯВЛЕНИЕ В МАГАЗИНАХ

ИСПРАВЛЕНИЯ
1. Убрана диагностика V28.5/V28.6 (никаких MessageBox при загрузке, никакого мигания).
2. Штатный коэффициент серии: Probability=2 (вместо 5).
3. На входе в обычный магазин использован уже существующий обход StockAt:
   для стандартных серий 120–124 с фиксированным шансом 35% применяется
   серия Nanotech с последующей штатной инициализацией самого мода.
4. Шанс определяется по стабильному ID предмета, не перебрасывается при
   повторном открытии магазина и не требует сохранения доп. состояния.
5. При отсутствии необходимого оформления серия возвращается на исходную;
   чужие/редкие серии не трогаются.
6. Военные, пиратские и специальные категории не меняются.
7. Не создаёт дополнительных товаров, не ограничивает пятью корпусами.
8. Нет DLL/хуков/привязки EXE/ежедневных новых проверок/всплывающих окон.
   Используется только существующий скрипт StockAt во время работы с магазином.

ПРОВЕРКА
- Закрыть игру.
- Установить содержимое RELEASE/Mods поверх ПОЛНОЙ V27.1 + обновлений.
  Для тестовых функций вместо RELEASE выбрать TEST (не оба).
- Не устанавливать одновременно с V28.6: V28.7 полностью заменяет DAT V28.6.
- Загрузить сохранение, посмотреть несколько планетарных магазинов.
  В уже существующих магазинах могут преобразоваться обычные базовые корпуса,
  а в следующих обновлениях есть также штатный шанс Probability=2.

Проверены DAT и структура кода; реальное поведение на клиенте игры не запускалось.
35% — только для подходящих базовых корпусов, НЕ для каждого магазина и не
процент появления за ход. Частота зависит от уже имеющегося ассортимента.
'''

with ZipFile(BASE) as zin, ZipFile(OUT,'w',ZIP_DEFLATED,compresslevel=9) as zout:
    for variant in ['TEST','RELEASE']:
        root=variant+'/'+PREFIX
        main,mm=unpack(zin.read(root+'CFG/Main.dat'))
        lang,lm=unpack(zin.read(root+'CFG/Rus/Lang.dat'))
        original_main_bytes=zin.read(root+'CFG/Main.dat')
        old_lang={p:(e[1],e[3] if e[1]==1 else None) for p,e in walk(lang)}
        hull=group(group(lang,'HullType'),'FHDNT_Nanotechnician')
        prob=parm(hull,'Probability')
        assert prob[3]=='5',prob
        prob[3]='2'
        fhdnt=group(lang,'FHDNT')
        assert parm(fhdnt,'Distribution27')[3]=='VANILLA'
        assert not any(e[2]=='ShopExtraChance28' for e in fhdnt[1])
        fhdnt[1].append(mkparm('ShopExtraChance28','35'))
        fhdnt[1].sort(key=lambda e:e[2])
        code=group(fhdnt,'Code')
        stock=group(code,'StockAt')
        stmt=parm(stock,'0008')
        assert stmt[3]=="ExecuteCodeFromString(GenerateCodeStringFromBlock('FHDNT.Code.PrepareHull27'),'h',nt_hull);"
        stmt[3]="ExecuteCodeFromString(GenerateCodeStringFromBlock('FHDNT.Code.MarketTune28'),'h',nt_hull); " + stmt[3]
        assert not any(e[2]=='MarketTune28' for e in code[1])
        code[1].append(mkgroup('MarketTune28',[mkparm(str(i).zfill(4),s) for i,s in enumerate(market_code)]))
        code[1].sort(key=lambda e:e[2])
        onload=group(group(main,'BV'),'OnLoad')
        assert [e[2] for e in onload[1]]==['Runtime']
        assert not any('SHOP PROBE' in str(e) for _,e in walk(main) if e[1]==1)
        assert not any('MessageBox' in e[3] for p,e in walk(main) if p.startswith('BV.OnLoad') and e[1]==1)
        mi=zin.read(root+'ModuleInfo.txt')
        desc=mi.decode('utf-16').replace('V28.2 LEVEL40 VANILLA P5','V28.7 MARKET P2 + BASE35').encode('utf-16')
        zout.writestr(root+'CFG/Main.dat',pack(main,mm))
        zout.writestr(root+'CFG/Rus/Lang.dat',pack(lang,lm))
        zout.writestr(root+'ModuleInfo.txt',desc)
        # Keep exact same art payload, only three config/metadata modifications.
        for n in zin.namelist():
            if n.startswith(root+'DATA/'):
                zout.writestr(n,zin.read(n))
        # Verify exact (repacked) structures and delta
        new_m,_=unpack(pack(main,mm));new_l,_=unpack(pack(lang,lm))
        assert parm(group(group(new_l,'HullType'),'FHDNT_Nanotechnician'),'Probability')[3]=='2'
        assert parm(group(new_l,'FHDNT'),'ShopExtraChance28')[3]=='35'
        assert 'MarketTune28' in parm(group(group(group(new_l,'FHDNT'),'Code'),'StockAt'),'0008')[3]
        changed_main=set()
        changed_lang={p for p,e in walk(new_l) if old_lang.get(p)!=(e[1],e[3] if e[1]==1 else None)}
        assert pack(new_m,mm)==original_main_bytes, 'Main.dat changed unexpectedly'
        assert changed_lang=={'HullType.FHDNT_Nanotechnician.Probability','FHDNT.ShopExtraChance28',
            'FHDNT.Code.StockAt.0008','FHDNT.Code.MarketTune28',
            *(f'FHDNT.Code.MarketTune28.{i:04d}' for i in range(len(market_code)))},changed_lang
        print(variant, 'Lang changed',len(changed_lang),'Main untouched, byte-for-byte')
    zout.writestr('README_RU.txt',readme)
    zout.writestr('SOURCE/build_nanotech_v28_7_market.py',Path(__file__).read_bytes())
with ZipFile(OUT) as chk:
    assert chk.testzip() is None
    for v in ['TEST','RELEASE']:
        assert not any('PROBE' in n for n in chk.namelist())
print(OUT,OUT.stat().st_size,hashlib.sha256(OUT.read_bytes()).hexdigest())
